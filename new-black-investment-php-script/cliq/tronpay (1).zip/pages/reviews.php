<?php if(!defined('FastCore')){exit('Opss!');}
#Заголовки
$opt = array(
'title' => 'Add banner',
'keywords' => 'site ads, reklam, site link, banners adverts',
'description' => 'With us you can attract customers and open new channels of profit for your business.'
);
?>
<p class="about text-center m-3">
Looking for the best way to advertise your cryptocurrency business and reach new audience? <br>
In need of a one-stop solution to cryptocurrency advertising?
 <br> 
	<b>Start growing your audience now. This is where troncoin.pro can help!<br>
It is only a moment that separates your amazing crypto business from the audience and traffic it deserves! Why make them wait?
</b></p>

<div class="row m-3">
<div class="col-lg-4">
<div class="card"><div class="card-body text-center"><i class="fa fa-signal" style="font-size: 25px;"></i><br><h4>Daily visitors</h4> <h3 class="mb-1"><b>5 000+</b></h3></div></div>
</div>
<div class="col-lg-4">
<div class="card"><div class="card-body text-center"><i class="fa fa-briefcase" style="font-size: 25px;"></i><br><h4>Price per weeks</h4> <h3 class="mb-1"><b>300 {!VAL!}</b></h3></div></div>
</div>
<div class="col-lg-4">
<div class="card"><div class="card-body text-center"><i class="fa fa-copy" style="font-size: 25px;"></i><br><h4>Banner formats</h4> <h3 class="mb-1"><b>Horizontal banners</b></h3></div></div>
</div>
</div>

<center>
<div class="card" style="max-width: 700px;">
<div class="card-body text-center">
<h4 class="card-title">After depositing the balance of 300 {!VAL!}<br> write to our mailbox</h4>
	<div class="tarif-info2" style="color:#fc2;"><b><?=$config->email;?></b></div>
					<small>You can send materials for advertising right away
					</small>
</div></div>

</center>