<?php
header('Location: /user/dashboard'); return;
/**
  * Сокрытие директории файлом index.php либо .htaccess
 */
?>