<?php if(!defined('FastCore')){exit('Opss!');}
# Заголовки
$opt = array(
    'title' => 'Bounty System',
    'description' => 'script game buy shop money game buy script php fastcore shop script hyip.'
    );
?>

<h5 class="text-center">We are ready to actively encourage our users<br>
and in addition to the affiliate program, we provide a bonus for creating Video Reviews or posts of our Project. 
</h5>

<div class="row row-grid align-items-center m-2 m-xl-5"> 
<div class="col-md-2 text-center"><img src="/img/b1.png" style="width: 128px;"></div>
<div class="col-md-10">
<div class="p-3 about">
<h5 style="color:#f23;"><b>1 - Welcome bonus</b></h5>
<p>Welcome to our project! We are happy to reward every new member. Be active and earn money on our project.</p>
<div class="btn btn-danger"><b><i class="fa fa-gift"></i> REWARD: 100 {!VAL!}</b></div>
</div>
</div>
</div>
<!-- Post bounty -->

<div class="row row-grid align-items-center m-2 m-xl-5"> 
<div class="col-md-2 text-center"><img src="/img/b2.png" style="width: 128px;"></div>
<div class="col-md-10">
<div class="p-3 about">
<h5 style="color:#f23;"><b>2 - Facebook/Twitter/VK/Telegram</b></h5>
<p>Create a post/tweet of our project explaining your experience with us and get paid for it <br>
* Send us the link of the post/tweet<br>
* Your profile must be Public<br>
* Only one submission per week is allowed </p>
<div class="btn btn-danger"><b><i class="fa fa-gift"></i> REWARD: 20 - 100 {!VAL!}</b></div>
</div>
</div>
</div>
<!-- Post bounty -->


<div class="row row-grid align-items-center m-2 m-xl-5"> 
<div class="col-md-2 text-center"><img src="/img/b3.png" style="width: 128px;"></div>
<div class="col-md-10">
<div class="p-3 about">
<h5 style="color:#f23;"><b>3 - Monitors/Blogs:</b></h5>
<p>Create a listing for our game on your monitor or blog and get paid for it<br>
* Post a thread or comment on a social media forum or blog.<br>
* Blog post must have a minimum of 200 words.<br>
* Blog post must have your referral link on the very last part of the blog post.<br>
* Your Monitor listing must be available on Public and has your referral link<br>
** Don't delete the Votes or blog. If you delete it, this action will be considered fraud and you'll be disqualified from participation in the bounty program and admin reserves the right to block your account and payout. </p>
<div class="btn btn-danger"><b><i class="fa fa-gift"></i> REWARD: 100 - 1000 {!VAL!}</b></div>
</div>
</div>
</div>
<!-- Post bounty -->


<div class="row row-grid align-items-center m-2 m-xl-5"> 
<div class="col-md-2 text-center"><img src="/img/b4.png" style="width: 128px;"></div>
<div class="col-md-10">
<div class="p-3 about">
<h5 style="color:#f23;"><b>4 - Review Videos:</b></h5>
<p>Create a review video and post it on your YouTube channel or Facebook page and get paid for it<br>
* Send us the video link<br>
* The minimum video length is 1 minute.<br>
* Only 1 video per week will be paid. Leave your referral link in the video description box.<br>
Don't delete the video. If you delete the video, this action will be considered fraud and you'll be disqualified from participation in the bounty program and admin reserves the right to block your account and payout. The company reserves the right to provide the bonus at its full discretion, depending on the quality of the video content.</p>
<div class="btn btn-danger"><b><i class="fa fa-gift"></i> REWARD: 100 - 3000 {!VAL!}</b></div>
</div>
</div>
</div>
<!-- Post bounty -->