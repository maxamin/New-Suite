</div> <!-- Col-10 content-->

<div class="p-2" style="background: #e9ecef;">
© Powered by <b><a class="text-dark" href="https://vk.com/fastcore">FastCore</a></b>. 2019 - <?=date('Y');?> | Генерация страницы: {!GEN_PAGE!} сек.
</div>

</div> <!-- Col-10 P-0-->
</div> <!-- Row-->
</body>
</html>