<center><h3><i><span style="font-size: 330%;">4</span><span style="font-size: 250%;">0</span><span style="font-size: 180%;">4</span></i></h3>
<p>Страница не найдена.</p>
<a href="/" class="btn btn-lg btn-info">Главная</a>
</center>