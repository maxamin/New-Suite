<style>
  .livecoinwatch-widget-6 {
    background: #333 !important;
  }
</style>

<div class="text-center text-light footer">
 <div class="text-center">
<div class="buyban"><a class="buybut" href="/adverts" title="Add banner 700 {!VAL!}/weeks"></a>     
   <a href="https://cutt.ly/BwhNHgsg" target="_blank" title="Go">
  <img src="https://troncoin.pro/img/360vavada.png" style="max-width:100%;" class="d-md-none d-block" alt="banner line">
  <img src="https://troncoin.pro/img/1200vavada.png" style="max-width:100%;" class="d-none d-md-block" alt="banner block">
  </a>
</div>
</div>
<hr>
<div class="text-center text-light footer pb-0" style="border-radius: 0 0 1em 1em;">
<script defer src="https://www.livecoinwatch.com/static/lcw-widget.js"></script> 
<div class="row">
<div class="col-lg-3 ps-4">
<div class="livecoinwatch-widget-6" lcw-coin="TRX" lcw-base="USD" lcw-period="d" lcw-color-tx="#dde" lcw-color-bg="#1f2434" lcw-border-w="0" ></div>

</div>
<div class="col-lg-9">
<div class="livecoinwatch-widget-5" lcw-base="USD" lcw-color-tx="#ffffff" lcw-marquee-1="coins" lcw-marquee-2="none" lcw-marquee-items="20" ></div>

</div>
</div></div>
</div>
</div>


<style>
.linkcopy { color: #fff; }
.linkcopy:hover { color: #fc2; }

</style>

<!-- GTranslate: https://gtranslate.io/ -->

<style type="text/css">
#goog-gt-tt {display:none !important;}
.goog-te-banner-frame {display:none !important;}
.goog-te-menu-value:hover {text-decoration:none !important;}
body {top:0 !important;}
#google_translate_element2 {display:none!important;}
</style>

<div id="google_translate_element2"></div>
<script type="text/javascript">
function googleTranslateElementInit2() {new google.translate.TranslateElement({pageLanguage: 'en',autoDisplay: false}, 'google_translate_element2');}
</script><script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit2"></script>

<script type="text/javascript">
/* <![CDATA[ */
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('6 7(a,b){n{4(2.9){3 c=2.9("o");c.p(b,f,f);a.q(c)}g{3 c=2.r();a.s(\'t\'+b,c)}}u(e){}}6 h(a){4(a.8)a=a.8;4(a==\'\')v;3 b=a.w(\'|\')[1];3 c;3 d=2.x(\'y\');z(3 i=0;i<d.5;i++)4(d[i].A==\'B-C-D\')c=d[i];4(2.j(\'k\')==E||2.j(\'k\').l.5==0||c.5==0||c.l.5==0){F(6(){h(a)},G)}g{c.8=b;7(c,\'m\');7(c,\'m\')}}',43,43,'||document|var|if|length|function|GTranslateFireEvent|value|createEvent||||||true|else|doGTranslate||getElementById|google_translate_element2|innerHTML|change|try|HTMLEvents|initEvent|dispatchEvent|createEventObject|fireEvent|on|catch|return|split|getElementsByTagName|select|for|className|goog|te|combo|null|setTimeout|500'.split('|'),0,{}))
/* ]]> */
</script>
<!-- GTranslate end --> 


		<div class="container-xl text-center p-3">
<b> <?=$config->sitename;?> </b> © <?=date('Y');?> - All rights reserved.
<!-- Генерация страницы: {!GEN_PAGE!} -->

</div>

<script src="/assets/js/surf.js"></script>

<script src="/assets/js/bootstrap.bundle.min.js"></script>
<script src="/assets/js/common.js"></script>


</body>
</html>