<center class="alert bg-warning text-uppercase" style="border: 4px dashed #333;">
<span  class="display-4"><i class="fa fa-warning"></i></span><br/>
<b>На этой странице проводятся технические работы. </b><br/>
Приносим извинения за доставленные неудобства. Попробуйте зайти позже.
</center>