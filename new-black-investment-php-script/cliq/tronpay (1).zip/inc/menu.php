<div class="clearfix"></div>
<div class="clear"></div>


<div class="leftbar">
	

<div class="menubar">
    <div class="menu2 divide text-uppercase">
	<i class="fa fa-bars"></i><span>Account menu</span>
    </div>
    <div class="menu__wrapper pt-0">

	<ul class="leftbar__menu mb-0 mt-0">
		<li><a href="/user/mining"><i class="fa fa-yin-yang fa-spin"></i><span>Mining </span> </a></li>
		<li><a href="/user/surf"><i class="fa fa-play"></i><span>PTC EARN</span></a></li>
		<li><a href="/user/bonus"><i class="fa fa-gift"></i><span>Bonus</span></a></li>
		<li><a href="/user/finance"><i class="fa fa-money-bill"></i><span>My Finance</span></a></li>
		<li><a href="/user/refs"><i class="fa fa-users"></i><span>Referrals</span></a></li>
		<li><a href="/user/logout"><i class="fa fa-sign-out-alt"></i><span>Exit</span></a></li>
	</ul>
</div></div></div>
