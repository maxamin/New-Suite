<div class="mt-3"><hr>
	<div class="p-2">
		<h5 class="text-uppercase mb-0 text-center"><b>When you top up your balance, you get bonus</b></h5>
	</div>

	<div class="row">
<div class="col-lg-3">
	<div style="border: 2px solid #f23;">
	<h5 style="background: #f23;color: #fff;font-size: 28px;font-weight: bold;">+5%</h5>
	<h5 class="text-uppercase">deposit<br>from 100 <span class="notranslate">{!VAL!}</span></h5>
	</div>
</div>
<div class="col-lg-3">
	<div style="border: 2px solid #f23;">
	<h5 style="background: #f23;color: #fff;font-size: 28px;font-weight: bold;">+10%</h5>
	<h5 class="text-uppercase">deposit<br>from 500  <span class="notranslate">{!VAL!}</span></h5>
	</div>
</div>
<div class="col-lg-3">
	<div style="border: 2px solid #f23;">
	<h5 style="background: #f23;color: #fff;font-size: 28px;font-weight: bold;">+20%</h5>
	<h5 class="text-uppercase">deposit<br>from 1000  <span class="notranslate">{!VAL!}</span></h5>
	</div>
</div>
<div class="col-lg-3">
	<div style="border: 2px solid #f23;">
	<h5 style="background: #f23;color: #fff;font-size: 28px;font-weight: bold;">+30%</h5>
	<h5 class="text-uppercase">deposit<br>from 2500  <span class="notranslate">{!VAL!}</span></h5>
	</div>
</div>
	</div>
</div>