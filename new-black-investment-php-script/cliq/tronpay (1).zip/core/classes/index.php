<?php
header('Location: /'); return;
/**
  * Сокрытие директории файлом index.php либо .htaccess
 */
?>